
import { useEffect } from "react";


export default function App() {

	const [artigos, definirArtigos] = useEffect([]);
	const [comentarios, definirComentarios] = useEffect([]);
	const [perfil, definirPerfil] = useEffect({});

	useEffect(() => {

		/* 
	
			Adicione a comunicação 
			com servidor aqui...

			Endpoint

			GET http://localhost:3000/posts

			GET http://localhost:3000/comments

			GET http://localhost:3000/profile

			Response

			{
				"posts": [
					{ 
						"id": 1, 
						"title": "json-server", 
						"author": "typicode" 
					}
				],
				"comments": [
					{ 
						"id": 1, 
						"body": "some comment", 
						"postId": 1 
					}
				],
				"profile": { 
					"name": "typicode" 
				}
			}
		
		*/


	}, []);


	/*
		Renderize as tarefas em tela...
		utilize map()
	*/
	return (
		<></>
	)
}
